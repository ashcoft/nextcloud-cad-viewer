<?php

declare(strict_types=1);

use OCP\Util;

Util::addScript(OCA\CadViewer\AppInfo\Application::APP_ID, OCA\CadViewer\AppInfo\Application::APP_ID . '-main');
Util::addStyle(OCA\CadViewer\AppInfo\Application::APP_ID, OCA\CadViewer\AppInfo\Application::APP_ID . '-main');

?>

<div id="cadviewer"></div>
